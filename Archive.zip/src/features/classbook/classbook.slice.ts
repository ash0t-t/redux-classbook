import { createSlice } from "@reduxjs/toolkit";

const initialState = {}
const ClassBookSlice = createSlice({
    name:'classbook',
    initialState,
    reducers:{}
})

export const classReducer= ClassBookSlice.reducer