import { Link } from "react-router-dom"

export const ClassBook = () => {
    return <>
        <h3>classbook</h3>
        <Link to={'/students'}>Students</Link>
    </>
}