
export interface IState{
    lessons:ILesson[]
}

export interface ILesson{
    id:string
    title:string
    rating:IRating[]
}

export interface IRating{
    id:string
    student:string
    rate:number
}