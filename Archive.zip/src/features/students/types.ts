export interface IStudent{
    id:string
    name:string
    surname:string
}