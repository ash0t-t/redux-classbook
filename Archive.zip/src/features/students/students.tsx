import { Link } from "react-router-dom"

export const Students = () => {
    return <>
        <h3>Students</h3>
        <Link to={'/'}>classbook</Link>

    </>
}